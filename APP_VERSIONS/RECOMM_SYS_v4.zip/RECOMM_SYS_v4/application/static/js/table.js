$(document).ready(function () {
    $('#movietable').DataTable();
});